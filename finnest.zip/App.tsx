
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate, Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, Wallet, Receipt, Target, PieChart, LogOut } from 'lucide-react';
import { dbService } from './services/dbService';
import { User } from './types';
import { DataProvider } from './contexts/DataContext';

// Components
import Dashboard from './components/Dashboard';
import Wallets from './components/Wallets';
import Transactions from './components/Transactions';
import Savings from './components/Savings';
import Reports from './components/Reports';
import Auth from './components/Auth';

const Navigation: React.FC<{ onLogout: () => void }> = ({ onLogout }) => {
  const location = useLocation();
  const isActive = (path: string) => location.pathname === path ? 'text-emerald-600 bg-emerald-50' : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50';
  const isMobileActive = (path: string) => location.pathname === path ? 'text-emerald-600' : 'text-slate-400 hover:text-slate-600';

  const links = [
    { path: '/', label: 'Home', icon: LayoutDashboard },
    { path: '/wallets', label: 'Wallets', icon: Wallet },
    { path: '/transactions', label: 'Activity', icon: Receipt },
    { path: '/savings', label: 'Savings', icon: Target },
    { path: '/reports', label: 'Reports', icon: PieChart },
  ];

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 h-screen bg-white border-r border-slate-200 fixed left-0 top-0 z-20">
        <div className="p-6 border-b border-slate-100 flex items-center gap-2">
          <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-lg">F</span>
          </div>
          <h1 className="text-xl font-bold text-slate-800">FinNest</h1>
        </div>
        
        <nav className="flex-1 p-4 space-y-2">
          {links.map((link) => (
            <Link 
              key={link.path} 
              to={link.path} 
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${isActive(link.path)}`}
            >
              <link.icon size={20} />
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-100">
          <button 
            onClick={onLogout}
            className="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-600 hover:bg-rose-50 hover:text-rose-600 w-full transition-all font-medium"
          >
            <LogOut size={20} />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-40 pb-safe">
        <div className="flex justify-around items-center h-16">
          {links.map((link) => (
            <Link 
              key={link.path} 
              to={link.path} 
              className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${isMobileActive(link.path)}`}
            >
              <link.icon size={20} />
              <span className="text-[10px] font-medium">{link.label}</span>
            </Link>
          ))}
        </div>
      </div>
      
      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md border-b border-slate-200 z-30 px-4 py-3 flex items-center justify-between">
         <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-lg">F</span>
          </div>
          <h1 className="text-lg font-bold text-slate-800">FinNest</h1>
        </div>
        <button onClick={onLogout} className="p-2 text-slate-400 hover:text-rose-500">
          <LogOut size={20} />
        </button>
      </div>
    </>
  );
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check local storage for session
    const storedUser = localStorage.getItem('finnest_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  const handleLogin = (userData: User) => {
    setUser(userData);
    localStorage.setItem('finnest_user', JSON.stringify(userData));
  };

  const handleLogout = async () => {
    await dbService.auth.signOut();
    localStorage.removeItem('finnest_user');
    setUser(null);
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-gray-50 text-emerald-600 font-bold animate-pulse">Connecting to Nest...</div>;

  if (!user) {
    return <Auth onLogin={handleLogin} />;
  }

  return (
    <Router>
      <DataProvider user={user}>
        <div className="min-h-screen bg-gray-50 flex">
          <Navigation onLogout={handleLogout} />
          {/* Added pb-20 to allow space for bottom nav on mobile */}
          <main className="flex-1 md:ml-64 p-4 md:p-8 pt-20 md:pt-8 pb-24 md:pb-8 overflow-y-auto min-h-screen">
            <Routes>
              <Route path="/" element={<Dashboard user={user} />} />
              <Route path="/wallets" element={<Wallets user={user} />} />
              <Route path="/transactions" element={<Transactions user={user} />} />
              <Route path="/savings" element={<Savings user={user} />} />
              <Route path="/reports" element={<Reports user={user} />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </main>
        </div>
      </DataProvider>
    </Router>
  );
}
