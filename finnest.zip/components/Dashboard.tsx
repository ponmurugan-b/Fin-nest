
import React, { useState } from 'react';
import { User, TransactionType } from '../types';
import { generateFinancialInsights } from '../services/geminiService';
import { ArrowUpRight, ArrowDownRight, Wallet as WalletIcon, Sparkles } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from 'recharts';
import { useData } from '../contexts/DataContext';

interface DashboardProps {
  user: User;
}

const Dashboard: React.FC<DashboardProps> = ({ user }) => {
  const { wallets, transactions, savingsGoals } = useData();
  const [insight, setInsight] = useState<string>('');
  const [loadingAI, setLoadingAI] = useState(false);

  const fetchAIInsight = async () => {
    setLoadingAI(true);
    const text = await generateFinancialInsights(transactions, wallets);
    setInsight(text);
    setLoadingAI(false);
  };

  const totalBalance = wallets.reduce((sum, w) => sum + w.balance, 0);
  
  const currentMonthTransactions = transactions.filter(t => {
    const d = new Date(t.date);
    const now = new Date();
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  });

  const income = currentMonthTransactions
    .filter(t => t.type === TransactionType.INCOME)
    .reduce((sum, t) => sum + t.amount, 0);

  const expense = currentMonthTransactions
    .filter(t => t.type === TransactionType.EXPENSE)
    .reduce((sum, t) => sum + t.amount, 0);

  // Data for Category Chart
  const expenseByCategory = currentMonthTransactions
    .filter(t => t.type === TransactionType.EXPENSE)
    .reduce((acc, t) => {
      acc[t.category_id] = (acc[t.category_id] || 0) + t.amount;
      return acc;
    }, {} as Record<string, number>);

  const chartData = Object.keys(expenseByCategory).map(key => ({
    name: key, // In real app, map ID to Category Name
    value: expenseByCategory[key]
  }));

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <header className="mb-6">
        <h2 className="text-xl md:text-2xl font-bold text-slate-800">Welcome Back</h2>
        <p className="text-sm md:text-base text-slate-500">Here's your financial overview for this month.</p>
      </header>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
        <div className="bg-emerald-500 text-white rounded-2xl p-6 shadow-lg shadow-emerald-500/20">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium text-emerald-100">Net Balance</h3>
            <WalletIcon className="opacity-80" />
          </div>
          <p className="text-3xl font-bold">₹{totalBalance.toLocaleString()}</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-1 gap-4 md:gap-0 md:contents">
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
             <div className="flex items-center justify-between mb-2 md:mb-4">
              <h3 className="text-sm md:text-base font-medium text-slate-500">Income</h3>
              <div className="p-2 bg-emerald-50 rounded-lg text-emerald-600">
                <ArrowUpRight size={16} md:size={20} />
              </div>
            </div>
            <p className="text-xl md:text-2xl font-bold text-slate-800">₹{income.toLocaleString()}</p>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
             <div className="flex items-center justify-between mb-2 md:mb-4">
              <h3 className="text-sm md:text-base font-medium text-slate-500">Expense</h3>
              <div className="p-2 bg-rose-50 rounded-lg text-rose-600">
                <ArrowDownRight size={16} md:size={20} />
              </div>
            </div>
            <p className="text-xl md:text-2xl font-bold text-slate-800">₹{expense.toLocaleString()}</p>
          </div>
        </div>
      </div>

      {/* AI Insights & Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Main Chart Area */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-800 mb-6">Spending Analysis</h3>
          {chartData.length > 0 ? (
             <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" tick={{fontSize: 12}} />
                  <YAxis tick={{fontSize: 12}} />
                  <Tooltip cursor={{fill: 'transparent'}} />
                  <Bar dataKey="value" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
             </div>
          ) : (
            <div className="h-64 flex items-center justify-center text-slate-400 text-center">
              No expense data yet. <br/>Start spending (or saving) to see charts!
            </div>
          )}
        </div>

        {/* AI Advisor / Goals Widget */}
        <div className="space-y-6">
          <div className="bg-gradient-to-br from-indigo-600 to-violet-600 rounded-2xl p-6 text-white shadow-lg shadow-indigo-500/20 relative overflow-hidden">
             <div className="relative z-10">
                <div className="flex items-center gap-2 mb-3">
                  <Sparkles size={20} className="text-yellow-300" />
                  <h3 className="font-bold">FinNest AI Advisor</h3>
                </div>
                {insight ? (
                  <div className="text-sm text-indigo-100 whitespace-pre-line leading-relaxed max-h-40 overflow-y-auto">
                    {insight}
                  </div>
                ) : (
                  <p className="text-sm text-indigo-100 mb-4">
                    Get personalized insights about your spending habits and savings opportunities.
                  </p>
                )}
                
                {!insight && (
                  <button 
                    onClick={fetchAIInsight}
                    disabled={loadingAI}
                    className="mt-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-sm font-medium transition-colors backdrop-blur-sm border border-white/10 w-full"
                  >
                    {loadingAI ? 'Analyzing...' : 'Analyze My Finances'}
                  </button>
                )}
             </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
            <h3 className="font-bold text-slate-800 mb-4">Savings Progress</h3>
            <div className="space-y-4">
              {savingsGoals.slice(0, 3).map(goal => (
                <div key={goal.id}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-slate-600">{goal.name}</span>
                    <span className="font-medium text-emerald-600">{Math.round((goal.current_amount / goal.target_amount) * 100)}%</span>
                  </div>
                  <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-emerald-500 rounded-full" 
                      style={{ width: `${Math.min((goal.current_amount / goal.target_amount) * 100, 100)}%` }}
                    />
                  </div>
                </div>
              ))}
              {savingsGoals.length === 0 && <p className="text-sm text-slate-400">No active savings goals.</p>}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default Dashboard;
