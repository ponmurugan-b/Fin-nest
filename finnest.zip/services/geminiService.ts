import { GoogleGenAI } from "@google/genai";
import { Transaction, Wallet } from "../types";

// NOTE: This requires process.env.API_KEY to be set in your build environment.
// If not present, the AI features will gracefully degrade or show a mock response.

let ai: GoogleGenAI | null = null;
if (process.env.API_KEY) {
  ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
}

export const generateFinancialInsights = async (transactions: Transaction[], wallets: Wallet[]) => {
  if (!ai) {
    console.warn("Gemini API Key missing. Returning mock insight.");
    return "AI Insights are unavailable in this demo environment. Please configure your API_KEY to receive personalized spending analysis.";
  }

  const txSummary = transactions.slice(0, 10).map(t => 
    `${t.date.split('T')[0]}: ${t.type} of ${t.amount} for category ${t.category_id}`
  ).join('\n');

  const walletSummary = wallets.map(w => `${w.name}: ${w.balance} ${w.currency}`).join(', ');

  const prompt = `
    Analyze these financial records briefly.
    Wallets: ${walletSummary}
    Recent Transactions:
    ${txSummary}
    
    Give me 3 bullet points of advice or observation. Keep it friendly and short.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Unable to generate insights at the moment.";
  }
};