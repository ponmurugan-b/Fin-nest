import { User, Wallet, Transaction, SavingsGoal, Category, TransactionType } from '../types';
import { DEFAULT_CATEGORIES } from '../constants';
import { pool } from '../lib/dbClient';

export const dbService = {
  auth: {
    signIn: async (email: string, password?: string) => {
      if (!password) throw new Error("Password required");
      try {
        const result = await pool.query('SELECT id, email FROM users WHERE email = $1 AND password = $2', [email, password]);
        if (result.rows.length === 0) {
          return { user: null, error: { message: "Invalid email or password" } };
        }
        return { user: result.rows[0] as User, error: null };
      } catch (err: any) {
        return { user: null, error: err };
      }
    },
    signUp: async (email: string, password?: string) => {
      if (!password) throw new Error("Password required");
      try {
        const id = crypto.randomUUID();
        const result = await pool.query(
          'INSERT INTO users (id, email, password) VALUES ($1, $2, $3) RETURNING id, email',
          [id, email, password]
        );
        return { user: result.rows[0] as User, error: null };
      } catch (err: any) {
        return { user: null, error: err };
      }
    },
    signOut: async () => {
      // Client-side cleanup handled in App.tsx
      return;
    }
  },

  db: {
    getWallets: async (userId: string): Promise<Wallet[]> => {
      try {
        const { rows } = await pool.query('SELECT * FROM wallets WHERE user_id = $1 ORDER BY created_at ASC', [userId]);
        return rows;
      } catch (e) {
        console.error(e);
        return [];
      }
    },
    addWallet: async (wallet: Wallet) => {
      try {
        const { rows } = await pool.query(
          `INSERT INTO wallets (id, user_id, name, type, balance, currency) 
           VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
          [wallet.id, wallet.user_id, wallet.name, wallet.type, wallet.balance, wallet.currency]
        );
        return rows[0];
      } catch (e) {
        console.error(e);
        return null;
      }
    },
    
    getTransactions: async (userId: string): Promise<Transaction[]> => {
      try {
        const { rows } = await pool.query('SELECT * FROM transactions WHERE user_id = $1 ORDER BY date DESC', [userId]);
        return rows;
      } catch (e) {
        console.error(e);
        return [];
      }
    },
    addTransaction: async (tx: Transaction) => {
      try {
        // Transaction trigger in DB handles balance update
        const { rows } = await pool.query(
          `INSERT INTO transactions (id, user_id, wallet_id, amount, category_id, type, date, notes) 
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
          [tx.id, tx.user_id, tx.wallet_id, tx.amount, tx.category_id, tx.type, tx.date, tx.notes]
        );
        return rows[0];
      } catch (e) {
        console.error(e);
        return null;
      }
    },

    getSavingsGoals: async (userId: string): Promise<SavingsGoal[]> => {
      try {
        const { rows } = await pool.query('SELECT * FROM savings_goals WHERE user_id = $1 ORDER BY created_at ASC', [userId]);
        return rows;
      } catch (e) {
        console.error(e);
        return [];
      }
    },
    addSavingsGoal: async (goal: SavingsGoal) => {
      try {
        const { rows } = await pool.query(
          `INSERT INTO savings_goals (id, user_id, name, target_amount, current_amount, deadline) 
           VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
          [goal.id, goal.user_id, goal.name, goal.target_amount, goal.current_amount, goal.deadline]
        );
        return rows[0];
      } catch (e) {
        console.error(e);
        return null;
      }
    },
    updateSavingsGoal: async (updatedGoal: SavingsGoal) => {
      try {
        const { rows } = await pool.query(
          `UPDATE savings_goals SET current_amount = $1 WHERE id = $2 RETURNING *`,
          [updatedGoal.current_amount, updatedGoal.id]
        );
        return rows[0];
      } catch (e) {
        console.error(e);
        return null;
      }
    },

    getCategories: async (): Promise<Category[]> => {
      return DEFAULT_CATEGORIES;
    }
  }
};
